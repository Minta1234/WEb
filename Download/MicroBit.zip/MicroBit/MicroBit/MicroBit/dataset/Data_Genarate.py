import random
import os

# =========================
# PATH (โฟลเดอร์เดียวกับไฟล์นี้)
# =========================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_FILE = os.path.join(BASE_DIR, "train_data.py")

# =========================
# CONFIG
# =========================
SAMPLES = 100000
NOISE_PROB = 0.05

# =========================
# HELPER
# =========================
def one_hot(i):
    return [1 if j == i else 0 for j in range(4)]

def noise(bit):
    if random.random() < NOISE_PROB:
        return 1 - bit
    return bit

# =========================
# GENERATE DATA
# =========================
rows = []

for _ in range(SAMPLES):
    L = noise(random.choice([0, 1]))
    R = noise(random.choice([0, 1]))

    # teacher logic
    if L == 0 and R == 0:
        action = 0      # FORWARD
    elif L == 0 and R == 1:
        action = 1      # LEFT
    elif L == 1 and R == 0:
        action = 2      # RIGHT
    else:
        action = 3      # STOP

    rows.append([L, R] + one_hot(action))

# =========================
# WRITE PYTHON FILE
# =========================
with open(OUT_FILE, "w") as f:
    f.write("data = [\n")
    for r in rows:
        f.write(f"    {r},\n")
    f.write("]\n")

print("Generated Python dataset:")
print(OUT_FILE)
print("Samples:", len(rows))
