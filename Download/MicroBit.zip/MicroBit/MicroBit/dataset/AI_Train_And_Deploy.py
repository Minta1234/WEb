# ================================
# AI TRAIN + EXPORT + FLASH
# ================================

import numpy as np
import subprocess
import sys

# ================================
# 1) DATASET (INLINE)
# ================================
data = np.array([
    [1,0,0,0,1,0],
    [1,0,0,0,1,0],
    [1,1,0,0,0,1],
    [0,0,1,0,0,0],
    [0,0,1,0,0,0],
    [1,1,0,0,0,1],
    [0,1,0,1,0,0],
    [0,1,0,1,0,0],
], dtype=float)

# X = [L, R, bias]
X = np.hstack([
    data[:, 0:2],
    np.ones((len(data), 1))
])

# Y = one-hot actions
Y = data[:, 2:6]

print("Loaded data:", data.shape)

# ================================
# 2) TRAIN MODEL
# ================================
W = np.linalg.pinv(X) @ Y
W = np.round(W, 3).tolist()

print("\nTRAINED WEIGHTS:")
for r in W:
    print(r)

# ================================
# 3) GENERATE micro:bit CODE
# ================================
microbit_code = f"""
from microbit import *

W = {W}

def sensor():
    return pin1.read_digital(), pin12.read_digital()

def infer(L, R):
    scores = [
        L*W[0][0] + R*W[1][0] + W[2][0],
        L*W[0][1] + R*W[1][1] + W[2][1],
        L*W[0][2] + R*W[1][2] + W[2][2],
        L*W[0][3] + R*W[1][3] + W[2][3],
    ]
    best = 0
    for i in range(1, 4):
        if scores[i] > scores[best]:
            best = i
    return best

def drive(a):
    if a == 0:
        pin16.write_analog(800)
        pin14.write_analog(800)
    elif a == 1:
        pin16.write_analog(300)
        pin14.write_analog(800)
    elif a == 2:
        pin16.write_analog(800)
        pin14.write_analog(300)
    else:
        pin16.write_analog(0)
        pin14.write_analog(0)

while True:
    L, R = sensor()
    drive(infer(L, R))
    sleep(10)
"""

with open("ai_microbit.py", "w") as f:
    f.write(microbit_code)

print("micro:bit code generated")

# ================================
# 4) FLASH
# ================================
try:
    subprocess.run(["uflash", "ai_microbit.py"], check=True)
    print("FLASH SUCCESS")
except Exception as e:
    print("FLASH ERROR:", e)
    sys.exit(1)
